#if !defined(APPLE_H)
#define APPLE_H

#include "gui.h"
#include "position.h"

/**
 * This class represents the apple on the screen that the snake has to eat.
 */
class Apple {
private:
    Position appleP;
    //Position appleP2;
public:
    /**
     * Construct an apple
     */
    Apple(int screenWidth, int screenHeight, vector<Position> snakepos);

    /**
     * Draw the apple using the GUI
     */
    void draw(Gui& gui);
    
    void update();
   
    Position getAppleP();
    //Position getAppleP2();
};

#endif
