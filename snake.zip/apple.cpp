#include <stdlib.h>
#include "apple.h"
#include "gui.h"
#include <cstdlib>
using namespace std;
//int x;
//int y;
Gui gui;


Apple::Apple(int screenWidth, int screenHeight, vector<Position> snakepos) {
    appleP.x = rand() % (screenWidth - 1)+ 1;
    appleP.y = rand() % (screenHeight - 1) + 1;
    
    for (int i = 0; i <= snakepos.size(); i++) {
        
        if (appleP.x != snakepos[i].x && appleP.y != snakepos[i].y) {
            break;
        }
    }  
}    
Position Apple::getAppleP() {
    return appleP;
}

void Apple::draw(Gui& gui) {
    
            
        gui.drawText("@", appleP.x, appleP.y, COLOR_RED, COLOR_BLACK);    

       
    
}

void Apple::update() {
    Position newApple;
    newApple.x = rand() % gui.screenWidth() + 0;
    newApple.y = rand() % gui.screenHeight() + 0;
    appleP.x = newApple.x;
    appleP.y = newApple.y;
}



    

