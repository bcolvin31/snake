#include "snake.h"
#include "gui.h"
int x;
int y;

Snake::Snake(int xpos, int ypos) {
    
    y = ypos;
    x = xpos;
    
    Position head(x, y);
    Position body1(x - 1, y);
    Position body2(x - 2, y);
    
    
    positions.push_back(head);
    positions.push_back(body1);
    positions.push_back(body2);
    
    
   
}

 vector<Position>& Snake::getPositions() {
     return positions;
 }

void Snake::draw(Gui& gui) {
    
    gui.drawText(">", positions[0].x, positions[0].y, COLOR_BLUE, COLOR_BLACK);
    
    if (newDirection == "RIGHT") {
    gui.drawText(">", positions[0].x, positions[0].y, COLOR_BLUE, COLOR_BLACK);
   }
    else if (newDirection == "LEFT") {
    gui.drawText("<", positions[0].x, positions[0].y, COLOR_BLUE, COLOR_BLACK);
   }
    else if (newDirection == "UP") {
    gui.drawText("^", positions[0].x, positions[0].y, COLOR_BLUE, COLOR_BLACK);
   }
    else if (newDirection == "DOWN") {
    gui.drawText("v", positions[0].x, positions[0].y, COLOR_BLUE, COLOR_BLACK);
   }
   
   for (int i = 1; i < positions.size(); i++) {
       
       gui.drawText("+", positions[i].x, positions[i].y, COLOR_BLUE, COLOR_BLACK);
   }
   
}

 void Snake::grow() {
    Position body(x, y);
    positions.push_back(body);
    
    
 }

void Snake::move() {

   
     for (int i = positions.size() - 1; i > 0; i--) {
        positions[i] = positions[i - 1];
    }  
    
    
    if (newDirection == "UP") {
        positions[0].y -= 1;
     
    }
    else if (newDirection == "DOWN") {
        positions[0].y += 1;
     
    }
    else if (newDirection == "LEFT") {
        positions[0].x -= 1;
            
    }
    else if (newDirection == "RIGHT") {
        positions[0].x += 1;
    
    }
    else {
        positions[0].x += 1;
   
    }
    
     
        
   
}


void Snake::changeDirection(string direction){
    //newDirection = direction;
    //newDirection = "Right";
    //direction = "RIGHT";
    
    if (direction == "RIGHT") {
        if (newDirection == "LEFT"){
        }
        else {
           newDirection = direction; 
        }
    }
    if (direction == "LEFT") {
        if (newDirection == "RIGHT"){
        }
        else {
           newDirection = direction; 
        }
    }
    if (direction == "UP") {
        if (newDirection == "DOWN"){
        }
        else {
           newDirection = direction; 
        }
    }
    if (direction == "DOWN") {
        if (newDirection == "UP"){
        }
        else {
           newDirection = direction; 
        }
    }
    
}


//use something like this to make game stop if snake hits wall

//if (ypos == screenHeight - 1) { // if the snake hits the border
          //  break; // break out of loop
        //}


