#include "gui.h"
#include "room.h"
#include "snake.h"
#include "apple.h"
#include "position.h"
#include <iostream>
using namespace std;


int main() {
    // Create the new Gui and start it. This clears the screen
    // and the Gui now controls the screen
    Gui gui;
    int screenHeight = gui.screenHeight();
    int screenWidth = gui.screenWidth();
    
    int xpos = screenWidth / 2;
    int ypos = screenHeight / 2;
    
    
    int score;
    
    int speed = 150;
    
    
    
    
    // Create the room, the snake and the apple. 
    
        

    
    
    // You will need to change the constructors later to pass more
    // information to the Snake and Apple constructors
    Room room(screenWidth, screenHeight);
    Snake snake(xpos, ypos);
    vector<Position> snakepos = snake.getPositions();
    Apple apple(screenWidth, screenHeight, snakepos);
    //Position applePos = apple.getAppleP();
    
    
    //snake cant go back on itself for the first keypress
    for (int i = 0; i < 2; i++) {
        snake.changeDirection("RIGHT");
    }

    // Enter main loop of the game. Use "break" to break out of the loop
    for (;;) {
        Position applePos = apple.getAppleP();
        
        // initial movement
        snake.move();
        
        // handle key presses
        int c = gui.getKeypress();
        
        
        // Do something with the key press
         if (c == 'q') {
            break; // breaks out of loop
         }
         
        else if (c == KEY_UP) {
        //     do something depending on what was pressed,
            snake.changeDirection("UP");
            snake.move();
         } 
         
        else if (c == KEY_DOWN) {
        //     do something else
            snake.changeDirection("DOWN");
            snake.move();
        }
        
        else if (c == KEY_RIGHT) {
            snake.changeDirection("RIGHT");
            snake.move();
        }
        
        else if (c == KEY_LEFT) {
            snake.changeDirection("LEFT");
            snake.move();
        }
        
        // Add your code to move the snake around the screen here.
        
        
        

        // Clear the screen
        gui.clear();

        // Redraw everything on the screen into an offscreen buffer,
        // including the room, the Snake and the apple
        room.draw(gui);
        // snake.draw(gui);
        snake.draw(gui);
        // apple.draw(gui);
        apple.draw(gui);
        
       
        
       
        // Display the new drawing all at once
        gui.refresh();

        // Detect whether the snake ate the apple, or it hit the wall
        // or it hit its own tail here
        
        if (apple.getAppleP().x == snake.getPositions()[0].x && apple.getAppleP().y == snake.getPositions()[0].y)  {
            score += 10;
            apple.update();
            snake.grow();
            speed -= 20; // make snake speed increase when it eats an apple
        }
        
        // snake hitting wall
        if (snake.getPositions()[0].x == screenWidth - 1 || snake.getPositions()[0].x == 0 || snake.getPositions()[0].y == screenHeight - 1 || snake.getPositions()[0].y == 0) {
            break;
            
        }
         
        //head hitting tail
        //bool snakeTail = false;
        bool snakeTail = false;
        for (int i = 1; i < snake.getPositions().size(); i++) {
            if ((snake.getPositions()[0].x == snake.getPositions()[i].x) && (snake.getPositions()[0].y == snake.getPositions()[i].y)) {
                snakeTail = true;
            }
        }
        
        //check if the variable in the if statement above is true
        if (snakeTail == true) {
            break;
        }
        
       
        
        
        //int i = 0;
        //if (i == 0) {
        //    snake.grow();
        //}

        // This call makes the program go quiescent for some time, so
        // that it doesn't run so fast. If the value in the call to
        // sleep is decreased, the game will speed up.
        
        gui.sleep(speed);
        
    }
}
